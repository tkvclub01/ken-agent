"""
KEN AGENT Core Module
"""

